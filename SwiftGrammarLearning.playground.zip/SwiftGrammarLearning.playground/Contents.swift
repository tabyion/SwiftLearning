import SwiftUI

struct Player{
    static var allPlayers: [Player] = []
    
    init(playerName: String){
        self.playerName = playerName
        self.currentHealth = 100
        self.livesRemaining = 5
    }
    
    init(playerName: String, livesRemaining: Int, currentHealth: Int) {
        self.playerName = playerName
        self.livesRemaining = livesRemaining
        self.currentHealth = currentHealth
    }
    
    init(playerName: String, livesRemaining: Int) {
        self.playerName = "VIP " + playerName
        self.livesRemaining = livesRemaining
        currentHealth = 10000
    }
    
    var playerName: String
    var livesRemaining: Int = 5{
        willSet{
            print("还剩\(newValue)条命！")
        }
        didSet{
            if livesRemaining != 0{
                print("满血复活！")
            }else{
                print("游戏结束! ")
            }
        }
    }
    var isPlayerOutOfLives: Bool{
        get{
            livesRemaining == 0 ? true : false
        }
        set {
            if newValue {
                livesRemaining = 0
            }
        }
    }
    var inventories: [InventoryItem] = []
    
    let maxHealth: Int = 100
    lazy var currentHealth = maxHealth
    
    func welcomePlayer(){
        print("欢迎玩家\(playerName), 生命值: \(livesRemaining)")
    }
    
    mutating func damaged(by health: Int){
        currentHealth -= health
        if currentHealth == 0 && livesRemaining > 0{
            livesRemaining -= 1
            currentHealth = maxHealth
        }
        if livesRemaining <= 0{
            print("游戏结束！")
        }
    }
    
    mutating func stateReport(){
        print("玩家名：\(playerName)")
        print("剩余\(livesRemaining)条命")
        print("当前生命值：\(currentHealth)")
    }
    
    static func recentAddPlayer() -> Player {
        allPlayers[allPlayers.count - 1]
    }
    
    mutating func addItem(inventoryName: String, inventoryDescription: String, healthBonus: Int){
        inventories.append(InventoryItem(inventoryName: inventoryName, inventoryDescription: inventoryDescription, healthBonus: healthBonus))
    }
    
    mutating func consumeItem(at index: Int){
        currentHealth += inventories.remove(at: index).healthBonus
    }
}

struct InventoryItem{
    var inventoryName: String
    var inventoryDescription: String
    var healthBonus: Int
}

var playerTab = Player(playerName: "Tab", livesRemaining: 10, currentHealth: 100)
var playerMike = Player(playerName: "Mike", livesRemaining: 10)
var playerLisa = Player(playerName: "Lisa")

playerTab.stateReport()
playerMike.stateReport()
playerLisa.stateReport()

Player.allPlayers.append(contentsOf: [playerTab, playerLisa, playerMike])
var name = Player.recentAddPlayer().playerName
print(name)
var playerCreater = Player(playerName: "创作者")
for _ in 1...3{
    playerCreater.addItem(inventoryName: "Apple", inventoryDescription: "回血", healthBonus: 50)
}
playerCreater.damaged(by: 100)
playerCreater.damaged(by: 100)
playerCreater.stateReport()
playerCreater.consumeItem(at: 0)
playerCreater.stateReport()
