import SwiftUI

struct Player {
    static var allplayers: [Player] = []
    var name: String
    var livesRemaining = 5 {
        willSet {
            print("Current lives: \(newValue)")
        }
        didSet {
            if livesRemaining != 0{
                print("New live!")
            } else {
                print("Game over!")
            }
        }
    }
    let maxHealth = 100
    lazy var currentHealth = maxHealth
    
    init(name: String) {
        self.name = name
    }
    
    init(name: String, livesRemaining: Int) {
        self.name = name
        self.livesRemaining = livesRemaining
    }
    
    init(name: String, livesRemaining: Int, currentHealth: Int){
        self.name = "VIP " + name
        self.livesRemaining = livesRemaining
        self.currentHealth = 10000
    }
    
    func welcomePlayer(){
        print("Current Account: \(name)")
    }
    
    mutating func damaged(by damagedHealth: Int){
        currentHealth -= damagedHealth
        if currentHealth <= 0 && livesRemaining > 0{
            livesRemaining -= 1
            currentHealth = 100
        }
        
        if livesRemaining == 0 {
            print("Game over!")
        }
    }
    
    mutating func stateReport(){
        print("Current information: \(self.name) \(self.livesRemaining) \(self.currentHealth)")
    }
    
    var isPlayOutOfLives: Bool {
        get {
            livesRemaining == 0 ? true : false
        }
        set {
            if newValue {
                livesRemaining = 0
            }
        }
    }
    
    mutating func bossDamaged() {
        print("Boss won! You are defeat!")
        self.isPlayOutOfLives = true
    }
    
    static func recentAddedPlayer() -> Player {
        allplayers[allplayers.count - 1]
    }
    
    var inventories: [InventoryItem] = []
    
    mutating func addItem(name: String, description: String, bonusHealth: Int) {
        inventories.append(InventoryItem(name: name, description: description, bonusHealth: bonusHealth))
        print("You add a/an \(name) in your inventory!")
    }
    
    mutating func consumeItem(at index: Int) {
        currentHealth += inventories.remove(at: index).bonusHealth
    }
}

struct InventoryItem {
    var name: String
    var description: String
    var bonusHealth: Int
}


var playWang = Player(name: "Wang Fei")
var playYang = Player(name: "TabYang", livesRemaining: 10, currentHealth: 5)
Player.allplayers.append(contentsOf: [playWang, playYang])
//playYang.stateReport()
//playWang.name
//playWang.welcomePlayer()
//playWang.stateReport()
//playWang.damaged(by: 70)
//playWang.stateReport()
//
//print(playWang.isPlayOutOfLives)
//playWang.bossDamaged()

print("The recent added player is \(Player.recentAddedPlayer().name)")

var playCreater = Player(name: "Creater")
playCreater.addItem(name: "Apple", description: "Food", bonusHealth: 50)
playCreater.damaged(by: 70)
playCreater.stateReport()
playCreater.consumeItem(at: 0)
playCreater.stateReport()


enum EnergySourse {
    case electricity
    case diesel
    case gasoline
}

var selectedVehicleEnergy = EnergySourse.electricity

var policyNote: String?
policyNote = Optional.none

switch selectedVehicleEnergy {
case .electricity:
    policyNote = "补贴10000"
case .diesel:
    policyNote = "无补贴"
case .gasoline:
    policyNote = "补贴2000"
}

print(policyNote ?? "NO")

class Car {
    var brand: String
    var year: String
    var energy: EnergySourse
    
    init(brand: String, year: String, energy: EnergySourse) {
        self.brand = brand
        self.year = year
        self.energy = energy
    }
}

class Sedan: Car {
    var assistantEquipped: Bool
    
    override init(brand: String, year: String, energy: EnergySourse) {
        assistantEquipped = false
        super.init(brand: brand, year: year, energy: energy)
    }
    
    func upgradeAssistant() {
        assistantEquipped = true
    }
}

class Truck: Car {
    override init(brand: String, year: String, energy: EnergySourse) {
        super.init(brand: brand, year: year, energy: energy)
    }
}

let teslaModel3 = Sedan(brand: "Tesla", year: "2019", energy: .electricity)
let toyotaHiLux = Truck(brand: "Toyata", year: "1968", energy: .diesel)

let cars: [Car] = [teslaModel3, toyotaHiLux]

var sedanCount: Int = 0
for car in cars {
    if car is Sedan {
        sedanCount += 1
    }
}
print("\(sedanCount)")

for car in cars {
    if let teslaModel3 = car as? Sedan {
        teslaModel3.upgradeAssistant()
    }
}

extension Car {
    var quickInfo: String {
        "The car's brand is \(brand), first built on \(year)"
    }
}

print(teslaModel3.quickInfo)

typealias Age = Int
var studentAge: Age = 19
print(studentAge)

typealias AppleStock = [String: Int]
var appleStock2019: AppleStock = ["一月": 2000000000000, "二月": 200000102000]

class ColorOfCar {
    var color: String
    init(color: String) {
        self.color = color
    }
}
typealias CarColor = ColorOfCar
let Audi: CarColor = ColorOfCar(color: "Green")

protocol Expressible {
    var name: String { get }
    
    init(name: String)
}

struct User: Expressible {
    var name: String
    
    // struct 自带 Initializer，所以默认 Conform Expressible Protocol
    init(name: String) {
        self.name = name
    }
}

// 通过 expression 来使 struct UserInfo conform Expressible Protocal
struct UserInfo {
    var name: String
    
    // struct 自带 Initializer，所以默认 Conform Expressible Protocol
    init(name: String) {
        self.name = name
    }
}

extension UserInfo: Expressible {}

// 可等性协议 Equatable Protocal
struct Todo {
    var content: String
    var id = UUID()
    
    static func == (lhs: Todo, rhs: Todo) -> Bool {
        return lhs.content == rhs.content
    }
}

extension Todo: Equatable { }

let todoOne = Todo(content: "Play the game!")
let todoTwo = Todo(content: "Do Homework")

if todoOne == todoTwo {
    print("The Two Todo-lists are the same.")
} else {
    print("NO")
}

// 可比性协议 Comparable Protocal
struct DateOfTheYear {
    let year: Int
    let month: Int
    let day: Int
}

extension DateOfTheYear: Equatable { }
extension DateOfTheYear: Comparable {
    static func < (lhs: DateOfTheYear, rhs: DateOfTheYear) -> Bool {
        if lhs.year != rhs.year {
            return lhs.year < rhs.year
        } else if lhs.month != rhs.month {
            return lhs.month < rhs.month
        } else if lhs.day != rhs.day {
            return lhs.day < rhs.month
        } else {
            return false
        }
    }
}

let dayOne = DateOfTheYear(year: 2019, month: 7, day: 30)
let dayTwo = DateOfTheYear(year: 2024, month: 8, day: 29)

if dayOne < dayTwo {
    print("日期1小于日期2")
} else {
    print("日期1大于日期2")
}

// 可哈希性协议 Hashable Protocal
extension DateOfTheYear: Hashable { }
let todos = [dayOne: todoOne, dayTwo: todoTwo]

// 可辨识性协议 Identifiable Protocal
extension Todo: Identifiable { }
// 在struct Todo 中添加属性 var id = UUID()
// UUID()用于生成可哈希的ID

// 可编码性协议 Codable Protocal
extension Todo: Codable { }

// 创建密码错误并写入错误协议 Error Protocol
enum PasswordError: Error {
    case notLongEnough
}

// 创建异常处理函数 func throw -> Bool 验证新密码是否符合密码长度
func validatePassword(_ password: String) throws -> Bool {
    if password.count < 6 {
        throw PasswordError.notLongEnough
    }
    return true
}

// do-try-catch 写法
var passwordOne = "12345"
do {
    try validatePassword(passwordOne)
    print("密码有效")
} catch PasswordError.notLongEnough {
    print("至少需要6位数字!")
}

var passwordTwo = "1234567"
if let validateResult = try? validatePassword(passwordTwo) {
    print("验证结果是\(validateResult),密码有效")
} else {
    print("密码至少需要6位数字！")
}

try! validatePassword(passwordTwo)

// task 创建并发环境 允许并行执行 async 异步函数，函数需要await关键字调用
Text("Concurrency")
    .task{
        await truck()
    }

func truck() async {
    for i in 0..<10000000000 {
        print(i)
    }
}
