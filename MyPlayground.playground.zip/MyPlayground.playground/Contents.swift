import SwiftUI

struct Player {
    static var allplayers: [Player] = []
    var name: String
    var livesRemaining = 5 {
        willSet {
            print("Current lives: \(newValue)")
        }
        didSet {
            if livesRemaining != 0{
                print("New live!")
            } else {
                print("Game over!")
            }
        }
    }
    let maxHealth = 100
    lazy var currentHealth = maxHealth
    
    init(name: String) {
        self.name = name
    }
    
    init(name: String, livesRemaining: Int) {
        self.name = name
        self.livesRemaining = livesRemaining
    }
    
    init(name: String, livesRemaining: Int, currentHealth: Int){
        self.name = "VIP " + name
        self.livesRemaining = livesRemaining
        self.currentHealth = 10000
    }
    
    func welcomePlayer(){
        print("Current Account: \(name)")
    }
    
    mutating func damaged(by damagedHealth: Int){
        currentHealth -= damagedHealth
        if currentHealth <= 0 && livesRemaining > 0{
            livesRemaining -= 1
            currentHealth = 100
        }
        
        if livesRemaining == 0 {
            print("Game over!")
        }
    }
    
    mutating func stateReport(){
        print("Current information: \(self.name) \(self.livesRemaining) \(self.currentHealth)")
    }
    
    var isPlayOutOfLives: Bool {
        get {
            livesRemaining == 0 ? true : false
        }
        set {
            if newValue {
                livesRemaining = 0
            }
        }
    }
    
    mutating func bossDamaged() {
        print("Boss won! You are defeat!")
        self.isPlayOutOfLives = true
    }
    
    static func recentAddedPlayer() -> Player {
        allplayers[allplayers.count - 1]
    }
    
    var inventories: [InventoryItem] = []
    
    mutating func addItem(name: String, description: String, bonusHealth: Int) {
        inventories.append(InventoryItem(name: name, description: description, bonusHealth: bonusHealth))
        print("You add a/an \(name) in your inventory!")
    }
    
    mutating func consumeItem(at index: Int) {
        currentHealth += inventories.remove(at: index).bonusHealth
    }
}

struct InventoryItem {
    var name: String
    var description: String
    var bonusHealth: Int
}


var playWang = Player(name: "Wang Fei")
var playYang = Player(name: "TabYang", livesRemaining: 10, currentHealth: 5)
Player.allplayers.append(contentsOf: [playWang, playYang])
//playYang.stateReport()
//playWang.name
//playWang.welcomePlayer()
//playWang.stateReport()
//playWang.damaged(by: 70)
//playWang.stateReport()
//
//print(playWang.isPlayOutOfLives)
//playWang.bossDamaged()

print("The recent added player is \(Player.recentAddedPlayer().name)")

var playCreater = Player(name: "Creater")
playCreater.addItem(name: "Apple", description: "Food", bonusHealth: 50)
playCreater.damaged(by: 70)
playCreater.stateReport()
playCreater.consumeItem(at: 0)
playCreater.stateReport()


enum EnergySourse {
    case electricity
    case diesel
    case gasoline
}

print("这辆车的动力类型为: \(EnergySourse.electricity)")
var selectedVechicleEnergy = EnergySourse.electricity
var policyNote: String?
policyNote = nil
policyNote = Optional.none

switch selectedVechicleEnergy{
case EnergySourse.electricity:
    policyNote = "电动车：补贴5000"
case EnergySourse.diesel:
    policyNote = "柴油车：补贴0"
case EnergySourse.gasoline:
    policyNote = "汽油车：补贴2000"
}

print(policyNote ?? "暂无说明")

class Car {
    var brand: String
    var year: String
    var energy: EnergySourse

    init(brand: String, year: String, energy: EnergySourse){
        self.brand = brand
        self.year = year
        self.energy = energy
    }
}

class Sedan: Car {
    var assistantEquipped: Bool
    override init(brand: String, year: String, energy: EnergySourse){
        assistantEquipped = false
        super.init(brand: brand, year: year, energy: energy)
    }
    func upgradeAssistant(){
        assistantEquipped = true
    }
}

class Truck: Car {
    var autoDrive: Bool
    override init(brand: String, year: String, energy: EnergySourse){
        autoDrive = false
        super.init(brand: brand, year: year, energy: energy)
    }
    func upgradeAutoDrive(){
        autoDrive = true
    }
}

let teslaModel3 = Sedan(brand: "Tesla", year: "2019", energy: EnergySourse.electricity)
let teslaTruck = Truck(brand: "Tesla", year: "2020", energy: EnergySourse.electricity)

let cars = [teslaTruck, teslaModel3]

var count: Int = 0
for car in cars{
    if car is Sedan{
        count += 1
    }
}
print(count)

for car in cars {
    if let teslaMode3 = car as? Sedan {
        teslaMode3.upgradeAssistant()
    }
}

extension Car {
    var quickInfo: String {
        "The brand of the car is \(brand), and the year is \(year)."
    }
}




